import java.util.ArrayList;
import java.util.Scanner;
public class Ring {
int max_processes;
int coordinator;
boolean processes[];
public Ring(int max) {
coordinator = max;
max_processes = max;
processes = new boolean[max];
for (int i = 0; i < max; i++) {
processes[i] = true;
System.out.println("P" + (i + 1) + " created.");
}
System.out.println("P" + coordinator + " is the coordinator");
}
void displayProcesses() {
for (int i = 0; i < max_processes; i++) {
System.out.println("P" + (i + 1) + " is " + (processes[i] ? "up." :
"down."));
}
System.out.println("P" + coordinator + " is the coordinator");
}
void initElection(int process_id) {
ArrayList<Integer> pid = new ArrayList<>();
int temp = process_id;
do {
if (processes[temp - 1]) {
pid.add(temp);
System.out.print("Process P" + temp + " sending the following
list:- " + pid + "\n");
}
temp = (temp % max_processes) + 1;
} while (temp != process_id);
coordinator = pid.stream().max(Integer::compare).orElse(coordinator);
System.out.println("Process P" + process_id + " has declared P" +
coordinator + " as the coordinator");
}
public static void main(String args[]) {
Ring ring = null;
int choice = 0;
Scanner sc = new Scanner(System.in);
while (true) {
System.out.println("Ring Algorithm");
System.out.println("1. Create processes");
System.out.println("2. Display processes");
System.out.println("3. Run election algorithm");
System.out.println("4. Exit Program");
System.out.print("Enter your choice:- ");
choice = sc.nextInt();
switch (choice) {
case 1:
System.out.print("Enter the total number of processes:- ");
int max_processes = sc.nextInt();
ring = new Ring(max_processes);
break;
case 2:
ring.displayProcesses();
break;
case 3:
System.out.print("Enter the process which will initiate
election:- ");
int election_process = sc.nextInt();
ring.initElection(election_process);
break;
case 4:
System.exit(0);
break;
default:
System.out.println("Error in choice. Please try again.");
break;
}
// Ask user which process crashed or is not responding
System.out.print("Enter the process number that has crashed or is not
responding: ");
int crashed_process = sc.nextInt();
ring.processes[crashed_process - 1] = false;
System.out.println("Process P" + crashed_process + " has crashed or is
not responding.");
// Ask for the initiator of the election
System.out.print("Enter the process which will initiate election: ");
int election_initiator = sc.nextInt();
ring.initElection(election_initiator);
}
}
}

/*
Ring Algorithm
1. Create processes
2. Display processes
3. Run election algorithm
4. Exit Program
Enter your choice:- 1
Enter the total number of processes:- 7
P1 created.
P2 created.
P3 created.
P4 created.
P5 created.
P6 created.
P7 created.
P7 is the coordinator
Enter the process number that has crashed or is not responding: 5
Process P5 has crashed or is not responding.
Enter the process which will initiate election: 4
Process P4 sending the following list:- [4]
Process P6 sending the following list:- [4, 6]
Process P7 sending the following list:- [4, 6, 7]
Process P1 sending the following list:- [4, 6, 7, 1]
Process P2 sending the following list:- [4, 6, 7, 1, 2]
Process P3 sending the following list:- [4, 6, 7, 1, 2, 3]
Process P4 has declared P7 as the coordinator
Ring Algorithm
1. Create processes
2. Display processes
3. Run election algorithm
4. Exit Program
Enter your choice:- 4
*/