import java.rmi.*;
import java.rmi.registry.*;
import java.util.Scanner;
public class Server {
public static void main(String args[]) {
try {
AreaCalculator obj = new AreaCalculatorImpl();
Naming.rebind("rmi://localhost/areaCalculator", obj);
System.out.println("Server Started");
} catch (Exception e) {
System.out.println(e);
}
}
}