import java.rmi.*;
import java.util.Scanner;
public class InputHandler extends Thread {
private Scanner scanner;
private double radius, length, width, base, height;
private int choice;
public InputHandler() {
scanner = new Scanner(System.in);
}
public void run() {
System.out.println("1. Calculate Circle Area");
System.out.println("2. Calculate Rectangle Area");
System.out.println("3. Calculate Triangle Area");
System.out.print("Enter your choice (1/2/3): ");
choice = scanner.nextInt();
switch (choice) {
case 1:
System.out.print("Enter radius of the circle: ");
radius = scanner.nextDouble();
break;
case 2:
System.out.print("Enter length of the rectangle: ");
length = scanner.nextDouble();
System.out.print("Enter width of the rectangle: ");
width = scanner.nextDouble();
break;
case 3:
System.out.print("Enter base of the triangle: ");
base = scanner.nextDouble();
System.out.print("Enter height of the triangle: ");
height = scanner.nextDouble();
break;
default:
System.out.println("Invalid choice.");
}
scanner.close();
}
public int getChoice() {
return choice;
}
public double getRadius() {
return radius;
}
public double getLength() {
return length;
}
public double getWidth() {
return width;
}
public double getBase() {
return base;
}
public double getHeight() {
return height;
}
}