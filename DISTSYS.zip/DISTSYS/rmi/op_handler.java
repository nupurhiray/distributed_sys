public class OutputHandler extends Thread {
private AreaCalculator obj;
private int choice;
private double radius, length, width, base, height;
public OutputHandler(AreaCalculator obj, int choice, double radius, double
length, double width, double base, double height) {
this.obj = obj;
this.choice = choice;
this.radius = radius;
this.length = length;
this.width = width;
this.base = base;
this.height = height;
}
public void run() {
try {
switch (choice) {
case 1:
System.out.println("Circle Area: " +
obj.calculateCircleArea(radius));
break;
case 2:
System.out.println("Rectangle Area: " +
obj.calculateRectangleArea(length, width));
break;
case 3:
System.out.println("Triangle Area: " +
obj.calculateTriangleArea(base, height));
break;
default:
System.out.println("Invalid choice.");
}
} catch (Exception e) {
System.out.println(e);
}
}
}