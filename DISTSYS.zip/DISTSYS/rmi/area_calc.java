import java.rmi.*;
public interface AreaCalculator extends Remote {
public double calculateCircleArea(double radius) throws RemoteException;
public double calculateRectangleArea(double length, double width) throws
RemoteException;
public double calculateTriangleArea(double base, double height) throws
RemoteException;
}