import java.rmi.*;
import java.rmi.server.*;
public class AreaCalculatorImpl extends UnicastRemoteObject implements
AreaCalculator {
AreaCalculatorImpl() throws RemoteException {
super();
}
public double calculateCircleArea(double radius) {
return Math.PI * radius * radius;
}
public double calculateRectangleArea(double length, double width) {
return length * width;
}
public double calculateTriangleArea(double base, double height) {
return 0.5 * base * height;
}
}