import java.rmi.Naming;
public class Client {
public static void main(String args[]) {
try {
AreaCalculator obj = (AreaCalculator)
Naming.lookup("rmi://localhost/areaCalculator");
InputHandler inputHandler = new InputHandler();
inputHandler.start();
inputHandler.join(); // Wait for input thread to finish
int choice = inputHandler.getChoice();
double radius = inputHandler.getRadius();
double length = inputHandler.getLength();
double width = inputHandler.getWidth();
double base = inputHandler.getBase();
double height = inputHandler.getHeight();
OutputHandler outputHandler = new OutputHandler(obj, choice, radius,
length, width, base, height);
outputHandler.start();
} catch (Exception e) {
System.out.println(e);
}
}
}

/* OUTPUT
Windows PowerShell
Copyright (C) Microsoft Corporation. All rights reserved.
Install the latest PowerShell for new features and improvements!
https://aka.ms/PSWindows
PS C:\Users\Mayur\Desktop\ass1> javac *.java
PS C:\Users\Mayur\Desktop\ass1> rmiregistry
PS C:\Users\Mayur\Desktop\ass1> java Server
Server Started
PS C:\Users\Mayur\Desktop\ass1> java Client
1. Calculate Circle Area
2. Calculate Rectangle Area
3. Calculate Triangle Area
Enter your choice (1/2/3): 1
Enter radius of the circle: 5
Circle Area: 78.53981633974483
PS C:\Users\Mayur\Desktop\ass1> java Client
1. Calculate Circle Area
2. Calculate Rectangle Area
3. Calculate Triangle Area
Enter your choice (1/2/3): 3
Enter base of the triangle: 10
Enter height of the triangle: 6
Triangle Area: 30.0
PS C:\Users\Mayur\Desktop\ass1>
*/

