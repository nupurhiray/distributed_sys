#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main() {
int n; // Number of processes
int token = 0; // Index of the current process holding the token
printf("Enter the number of processes: ");
scanf("%d", &n);
printf("Ring formed is as below: \n");
for (int i = 0; i < n; i++) {
printf("%d ", i);
}
printf("0\n");
while (1) {
printf("Process %d has the token.\n", token);
printf("Does process %d want to access the shared resource? (yes/no)\n",
token);
char choice[10];
scanf("%s", choice);
if (strcasecmp(choice, "yes") == 0) {
// Process wants to access the shared resource
printf("Process %d is in the critical section.\n", token);
// Simulating critical section
printf("Process %d is accessing the shared resource.\n", token);
// Release the token
printf("Process %d releases the token.\n", token);
// Pass the token to the next process
token = (token + 1) % n;
} else {
// Process doesn't want to access the shared resource, just pass the
token
printf("Process %d doesn't want to access the shared resource.\n",
token);
// Pass the token to the next process
token = (token + 1) % n;
}
// Simulate some delay for token passing
sleep(1); // Sleep for 1 second
}
return 0;
}









/*
PS C:\Users\Mayur\Desktop\DS Lab> gcc token.c
PS C:\Users\Mayur\Desktop\DS Lab> ./a
Enter the number of processes: 5
Ring formed is as below:
0 1 2 3 4 0
Process 0 has the token.
Does process 0 want to access the shared resource? (yes/no)
yes
Process 0 is in the critical section.
Process 0 is accessing the shared resource.
Process 0 releases the token.
Process 1 has the token.
Does process 1 want to access the shared resource? (yes/no)
yes
Process 1 is in the critical section.
Process 1 is accessing the shared resource.
Process 1 releases the token.
Process 2 has the token.
Does process 2 want to access the shared resource? (yes/no)
no
Process 2 doesn't want to access the shared resource.
Process 3 has the token.
Does process 3 want to access the shared resource? (yes/no)
yes
Process 3 is in the critical section.
Process 3 is accessing the shared resource.
Process 3 releases the token.
Process 4 has the token.
Does process 4 want to access the shared resource? (yes/no)
yes
Process 4 is in the critical section.
Process 4 is accessing the shared resource.
Process 4 releases the token.
Process 0 has the token.
Does process 0 want to access the shared resource? (yes/no)
yes
Process 0 is in the critical section.
Process 0 is accessing the shared resource.
Process 0 releases the token.
Process 1 has the token.
Does process 1 want to access the shared resource? (yes/no)
*/