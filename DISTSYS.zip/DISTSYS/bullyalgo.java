// import required classes and packages
import java.util.Scanner;
// create process class for creating a process having id and status
class Process {
// declare variables
public int id;
public String status;
// initialize variables using constructor
public Process(int id) {
this.id = id;
this.status = "active";
}
}
// create class BullyAlgoExample2 for understanding the concept of Bully algorithm
public class BullyAlgoExample2 {
// initialize variables and array
Scanner sc;
Process[] processes;
int n;
// initialize Scanner class object in constructor
public BullyAlgoExample2() {
sc = new Scanner(System.in);
}
// create ring() method for initializing the ring
public void ring() {
// get input from the user for processes
System.out.println("Enter total number of processes");
n = sc.nextInt();
// initialize processes array
processes = new Process[n];
for (int i = 0; i < n; i++) {
processes[i] = new Process(i);
}
}
// method to take user input for failed process ID
public int inputFailedProcess() {
System.out.println("Enter the ID of the process that has failed:");
return sc.nextInt();
}
// create election() method for electing process
public void performElection(int failedProcessId) {
// show failed process
System.out.println("Process having id " + failedProcessId + " fails");
// change status to Inactive of the failed process
processes[failedProcessId].status = "Inactive";
// declare and initialize variables
int idOfInitiator = 0;
boolean overStatus = true;
// use while loop to repeat steps
while (overStatus) {
boolean higherProcesses = false;
// iterate all the processes
for (int i = idOfInitiator + 1; i < n; i++) {
if (processes[i].status.equals("active")) {
System.out.println("Process " + idOfInitiator + " Passes
Election(" + idOfInitiator + ") message to process" + i);
higherProcesses = true;
}
}
// check for higher process
if (higherProcesses) {
// use for loop to again iterate processes
for (int i = idOfInitiator + 1; i < n; i++) {
if (processes[i].status.equals("active")) {
System.out.println("Process " + i + " Passes Ok(" + i + ")
message to process" + idOfInitiator);
}
}
// increment initiator id
idOfInitiator++;
} else {
// get the last process from the processes that will become
coordinator
int coord = getMaxValue();
// show process that becomes the coordinator
System.out.println("Finally Process " + coord + " Becomes
Coordinator");
for (int i = coord - 1; i >= 0; i--) {
if (processes[i].status.equals("active")) {
System.out.println("Process " + coord + " Passes
Coordinator(" + coord + ") message to process " + i);
}
}
System.out.println("End of Election");
overStatus = false;
break;
}
}
}
// create getMaxValue() method that returns index of max process
public int getMaxValue() {
int mxId = -99;
int mxIdIndex = 0;
for (int i = 0; i < processes.length; i++) {
if (processes[i].status.equals("active") && processes[i].id > mxId) {
mxId = processes[i].id;
mxIdIndex = i;
}
}
return mxIdIndex;
}
// main() method start
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
String answer;
do {
// create instance of the BullyAlgoExample2 class
BullyAlgoExample2 bully = new BullyAlgoExample2();
// call ring() method
bully.ring();
// take user input for failed process
int failedProcessId = bully.inputFailedProcess();
// perform election with the failed process ID
bully.performElection(failedProcessId);
System.out.println("Do you want to continue? (yes/no)");
answer = scanner.nextLine();
} while (answer.equalsIgnoreCase("yes"));
scanner.close();
}
}

/*
PS C:\Users\Mayur\Desktop\New folder (3)\New folder> javac BullyAlgoExample2.java
PS C:\Users\Mayur\Desktop\New folder (3)\New folder> java BullyAlgoExample2
Enter total number of processes
5
Enter the ID of the process that has failed:
3
Process having id 3 fails
Process 0 Passes Election(0) message to process1
Process 0 Passes Election(0) message to process2
Process 0 Passes Election(0) message to process4
Process 1 Passes Ok(1) message to process0
Process 2 Passes Ok(2) message to process0
Process 4 Passes Ok(4) message to process0
Process 1 Passes Election(1) message to process2
Process 1 Passes Election(1) message to process4
Process 2 Passes Ok(2) message to process1
Process 4 Passes Ok(4) message to process1
Process 2 Passes Election(2) message to process4
Process 4 Passes Ok(4) message to process2
Process 3 Passes Election(3) message to process4
Process 4 Passes Ok(4) message to process3
Finally Process 4 Becomes Coordinator
Process 4 Passes Coordinator(4) message to process 2
Process 4 Passes Coordinator(4) message to process 1
Process 4 Passes Coordinator(4) message to process 0
End of Election
Do you want to continue? (yes/no)
yes
Enter total number of processes
7
Enter the ID of the process that has failed:
5
Process having id 5 fails
Process 0 Passes Election(0) message to process1
Process 0 Passes Election(0) message to process2
Process 0 Passes Election(0) message to process3
Process 0 Passes Election(0) message to process4
Process 0 Passes Election(0) message to process6
Process 1 Passes Ok(1) message to process0
Process 2 Passes Ok(2) message to process0
Process 3 Passes Ok(3) message to process0
Process 4 Passes Ok(4) message to process0
Process 6 Passes Ok(6) message to process0
Process 1 Passes Election(1) message to process2
Process 1 Passes Election(1) message to process3
Process 1 Passes Election(1) message to process4
Process 1 Passes Election(1) message to process6
Process 2 Passes Ok(2) message to process1
Process 3 Passes Ok(3) message to process1
Process 4 Passes Ok(4) message to process1
Process 6 Passes Ok(6) message to process1
Process 2 Passes Election(2) message to process3
Process 2 Passes Election(2) message to process4
Process 2 Passes Election(2) message to process6
Process 3 Passes Ok(3) message to process2
Process 4 Passes Ok(4) message to process2
Process 6 Passes Ok(6) message to process2
Process 3 Passes Election(3) message to process4
Process 3 Passes Election(3) message to process6
Process 4 Passes Ok(4) message to process3
Process 6 Passes Ok(6) message to process3
Process 4 Passes Election(4) message to process6
Process 6 Passes Ok(6) message to process4
Process 5 Passes Election(5) message to process6
Process 6 Passes Ok(6) message to process5
Finally Process 6 Becomes Coordinator
Process 6 Passes Coordinator(6) message to process 4
Process 6 Passes Coordinator(6) message to process 3
Process 6 Passes Coordinator(6) message to process 2
Process 6 Passes Coordinator(6) message to process 1
Process 6 Passes Coordinator(6) message to process 0
End of Election
Do you want to continue? (yes/no)
no
PS C:\Users\Mayur\Desktop\New folder (3)\New folder>
*/